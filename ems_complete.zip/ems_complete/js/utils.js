// ═══════════════════════════════════════════════════════════════
//  UTILS  —  js/utils.js
// ═══════════════════════════════════════════════════════════════

// ─── DOM helpers ────────────────────────────────────────────────
function $(id) { return document.getElementById(id); }
function show(id) { const e=$(id); if(e) e.classList.remove('hidden'); }
function hide(id) { const e=$(id); if(e) e.classList.add('hidden'); }
function toggle(id) { const e=$(id); if(e) e.classList.toggle('hidden'); }
function setText(id,t) { const e=$(id); if(e) e.textContent=t; }
function setHTML(id,h) { const e=$(id); if(e) e.innerHTML=h; }

// ─── Toast notifications ────────────────────────────────────────
function showToast(msg, type='info') {
  let wrap = document.getElementById('toast-wrap');
  if (!wrap) {
    wrap = document.createElement('div');
    wrap.id = 'toast-wrap';
    wrap.className = 'toast-wrap';
    document.body.appendChild(wrap);
  }
  const icons = { success:'✅', error:'❌', warning:'⚠️', info:'ℹ️' };
  const t = document.createElement('div');
  t.className = `toast ${type}`;
  t.innerHTML = `<span>${icons[type]||'ℹ️'}</span><span>${msg}</span>`;
  wrap.appendChild(t);
  setTimeout(() => {
    t.style.transition = 'all .3s';
    t.style.opacity = '0';
    t.style.transform = 'translateX(16px)';
    setTimeout(() => t.remove(), 320);
  }, 3500);
}

// ─── Modal ───────────────────────────────────────────────────────
let _modalCb = null;
function showModal(title, bodyHTML, cb, btnLabel='Confirm', btnCls='btn-success') {
  const o = document.getElementById('modal-overlay');
  if (!o) return cb && cb(); // fallback if no modal in page
  document.getElementById('modal-title').textContent = title;
  document.getElementById('modal-body').innerHTML = bodyHTML;
  const btn = document.getElementById('modal-ok');
  if (btn) { btn.textContent = btnLabel; btn.className = `btn ${btnCls}`; }
  _modalCb = cb;
  o.classList.add('show');
}
function closeModal() {
  const o = document.getElementById('modal-overlay');
  if (o) o.classList.remove('show');
  _modalCb = null;
}
function confirmModal() {
  if (_modalCb) _modalCb();
  closeModal();
}

// ─── Alert helper ────────────────────────────────────────────────
function showAlert(id, type, msg) {
  const el = $(id);
  if (!el) return;
  const icons = { success:'✅', error:'❌', warning:'⚠️', info:'ℹ️' };
  el.className = `alert alert-${type}`;
  el.innerHTML = `<span class="alert-icon">${icons[type]||'ℹ️'}</span><div>${msg}</div>`;
  el.classList.remove('hidden');
}
function clearAlert(id) { const el=$(id); if(el){ el.classList.add('hidden'); el.innerHTML=''; } }

// ─── Status badge ────────────────────────────────────────────────
function statusBadge(s) {
  const map = {
    OPEN:      '<span class="badge badge-grey">⬜ Open</span>',
    SUBMITTED: '<span class="badge badge-orange">📤 Submitted</span>',
    VERIFIED:  '<span class="badge badge-green">✅ Verified</span>',
    FLAGGED:   '<span class="badge badge-red">🚩 Flagged</span>',
    PUBLISHED: '<span class="badge badge-green">🟢 Published</span>',
    PENDING:   '<span class="badge badge-orange">⏳ Pending</span>',
    APPROVED:  '<span class="badge badge-green">✅ Approved</span>',
  };
  return map[s] || `<span class="badge badge-grey">${s}</span>`;
}

// ─── Topbar nav highlight ────────────────────────────────────────
function highlightNav() {
  const pg = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(a => {
    a.classList.toggle('active', a.getAttribute('href') === pg);
  });
}

// ─── Topbar user info ────────────────────────────────────────────
function updateTopbarUser() {
  const s = getSession();
  const box = document.getElementById('nav-user-info');
  if (!box) return;
  if (s) {
    box.style.display = 'flex';
    setText('nav-role-badge', s.role.toUpperCase());
    setText('nav-username', s.name);
  } else {
    box.style.display = 'none';
  }
}

// ─── Number formatting ──────────────────────────────────────────
function fmt(n) { return Number(n).toLocaleString(); }
function pct(v, t) { return t ? Math.round(v / t * 100) : 0; }

// ─── Step indicator ─────────────────────────────────────────────
function setStep(total, current) {
  for (let i = 1; i <= total; i++) {
    const s = $(`step-${i}`);
    if (!s) continue;
    s.classList.remove('active','done');
    if (i < current) s.classList.add('done');
    else if (i === current) s.classList.add('active');
    const l = $(`step-line-${i}`);
    if (l) l.classList.toggle('done', i < current);
  }
}

// ─── Run on every page ───────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  highlightNav();
  updateTopbarUser();
});
