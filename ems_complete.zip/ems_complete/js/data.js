// ═══════════════════════════════════════════════════════════════
//  EMS DATA STORE  —  js/data.js
// ═══════════════════════════════════════════════════════════════

const DB = {

  voters: [
    { id:"VT-001", nid:"1990123456", name:"Rahim Uddin Ahmed",    constituency:"Dhaka-1", centre:"Mirpur High School",       centreAddr:"Road 12, Section 2, Mirpur, Dhaka-1216",   booth:"Booth 1A", hasVoted:true  },
    { id:"VT-002", nid:"1985234567", name:"Fatema Begum",          constituency:"Dhaka-1", centre:"Mirpur High School",       centreAddr:"Road 12, Section 2, Mirpur, Dhaka-1216",   booth:"Booth 1B", hasVoted:false },
    { id:"VT-003", nid:"1992345678", name:"Kamal Hossain Talukder",constituency:"Dhaka-2", centre:"Gulshan Model School",     centreAddr:"Road 5, Gulshan-1, Dhaka-1212",            booth:"Booth 2A", hasVoted:false },
    { id:"VT-004", nid:"1988456789", name:"Nasreen Akter",         constituency:"Dhaka-1", centre:"Mirpur High School",       centreAddr:"Road 12, Section 2, Mirpur, Dhaka-1216",   booth:"Booth 2A", hasVoted:true  },
    { id:"VT-005", nid:"1995567890", name:"Jabbar Mia",            constituency:"Dhaka-3", centre:"Dhanmondi Govt. School",   centreAddr:"Road 2, Dhanmondi, Dhaka-1205",            booth:"Booth 3A", hasVoted:false },
    { id:"VT-006", nid:"1982678901", name:"Sharmin Rahman",        constituency:"Dhaka-1", centre:"Pallabi Govt. School",     centreAddr:"Block D, Pallabi, Mirpur, Dhaka-1216",     booth:"Booth 2B", hasVoted:false },
    { id:"VT-007", nid:"1978789012", name:"Abul Kalam Azad",       constituency:"Dhaka-2", centre:"Gulshan Model School",     centreAddr:"Road 5, Gulshan-1, Dhaka-1212",            booth:"Booth 1A", hasVoted:false },
  ],

  constituencies: [
    { id:"CON-1", name:"Dhaka-1", desc:"Mirpur, Pallabi", totalVoters:45820, resultStatus:"PUBLISHED" },
    { id:"CON-2", name:"Dhaka-2", desc:"Gulshan, Banani",  totalVoters:38640, resultStatus:"PENDING"   },
    { id:"CON-3", name:"Dhaka-3", desc:"Dhanmondi",        totalVoters:41200, resultStatus:"PENDING"   },
    { id:"CON-4", name:"Dhaka-4", desc:"Motijheel",        totalVoters:36800, resultStatus:"PENDING"   },
    { id:"CON-5", name:"Dhaka-5", desc:"Tejgaon",          totalVoters:39500, resultStatus:"PENDING"   },
  ],

  stations: [
    { id:"STN-1", constituencyId:"CON-1", name:"Mirpur High School",     address:"Road 12, Section 2, Mirpur",  assignedPO:"po_mirpur",  status:"VERIFIED" },
    { id:"STN-2", constituencyId:"CON-1", name:"Pallabi Govt. School",   address:"Block D, Pallabi, Mirpur",    assignedPO:"po_pallabi", status:"VERIFIED" },
    { id:"STN-3", constituencyId:"CON-2", name:"Gulshan Model School",   address:"Road 5, Gulshan-1",           assignedPO:"po_gulshan", status:"OPEN"     },
    { id:"STN-4", constituencyId:"CON-3", name:"Dhanmondi Govt. School", address:"Road 2, Dhanmondi",           assignedPO:"po_dhm",    status:"OPEN"     },
  ],

  booths: [
    { id:"BTH-1A", stationId:"STN-1", number:"1A", issuedBallots:450, assignedAPO:"apo_mirpur",  status:"SUBMITTED" },
    { id:"BTH-1B", stationId:"STN-1", number:"1B", issuedBallots:430, assignedAPO:"apo_mirpur",  status:"VERIFIED"  },
    { id:"BTH-2A", stationId:"STN-1", number:"2A", issuedBallots:460, assignedAPO:"apo_mirpur",  status:"OPEN"      },
    { id:"BTH-2B", stationId:"STN-1", number:"2B", issuedBallots:440, assignedAPO:"apo_mirpur",  status:"FLAGGED"   },
    { id:"BTH-3A", stationId:"STN-2", number:"3A", issuedBallots:420, assignedAPO:"apo_pallabi", status:"VERIFIED"  },
    { id:"BTH-3B", stationId:"STN-2", number:"3B", issuedBallots:435, assignedAPO:"apo_pallabi", status:"VERIFIED"  },
  ],

  candidates: [
    { id:"CND-1", name:"Abdul Karim Talukder",  party:"Awami League",    partyShort:"AL",  constituencyId:"CON-1", symbol:"Boat",   color:"#2563eb", votes:4820 },
    { id:"CND-2", name:"Mohammad Rafiqul Islam",party:"BNP",             partyShort:"BNP", constituencyId:"CON-1", symbol:"Sheaf",  color:"#7c3aed", votes:3102 },
    { id:"CND-3", name:"Syed Aminur Rahman",    party:"Jatiya Party",    partyShort:"JP",  constituencyId:"CON-1", symbol:"Plough", color:"#059669", votes:980  },
    { id:"CND-4", name:"Nurjahan Begum",         party:"Independent",    partyShort:"IND", constituencyId:"CON-1", symbol:"Hammer", color:"#d97706", votes:310  },
    { id:"CND-5", name:"Hassan Ali Chowdhury",  party:"Awami League",    partyShort:"AL",  constituencyId:"CON-2", symbol:"Boat",   color:"#2563eb", votes:0    },
    { id:"CND-6", name:"Rezaul Haque Siddiqui", party:"BNP",             partyShort:"BNP", constituencyId:"CON-2", symbol:"Sheaf",  color:"#7c3aed", votes:0    },
    { id:"CND-7", name:"Laila Monjurul Islam",  party:"Jatiya Party",    partyShort:"JP",  constituencyId:"CON-3", symbol:"Plough", color:"#059669", votes:0    },
    { id:"CND-8", name:"Mahfuzur Rahman Babu",  party:"Independent",     partyShort:"IND", constituencyId:"CON-3", symbol:"Tree",   color:"#d97706", votes:0    },
  ],

  parties: [
    { id:"PTY-1", name:"Awami League",                    abbr:"AL",  founded:1949, leader:"Sheikh Hasina"     },
    { id:"PTY-2", name:"Bangladesh Nationalist Party",    abbr:"BNP", founded:1978, leader:"Khaleda Zia"       },
    { id:"PTY-3", name:"Jatiya Party",                    abbr:"JP",  founded:1986, leader:"Hussain M. Ershad" },
    { id:"PTY-4", name:"Jamaat-e-Islami Bangladesh",      abbr:"JIB", founded:1941, leader:"Shafiqur Rahman"   },
    { id:"PTY-5", name:"Gono Forum",                      abbr:"GF",  founded:1993, leader:"Kamal Hossain"     },
  ],

  officers: [
    { id:"OFF-1", name:"APO M. Karim",       role:"APO",   username:"apo_mirpur",  password:"pass123", stationId:"STN-1",  constituencyId:null  },
    { id:"OFF-2", name:"APO S. Begum",       role:"APO",   username:"apo_pallabi", password:"pass123", stationId:"STN-2",  constituencyId:null  },
    { id:"OFF-3", name:"PO A. Rahman",       role:"PO",    username:"po_mirpur",   password:"pass123", stationId:"STN-1",  constituencyId:null  },
    { id:"OFF-4", name:"PO B. Hossain",      role:"PO",    username:"po_pallabi",  password:"pass123", stationId:"STN-2",  constituencyId:null  },
    { id:"OFF-5", name:"ARO N. Hossain",     role:"ARO",   username:"aro_dhaka1",  password:"pass123", stationId:null,     constituencyId:"CON-1" },
    { id:"OFF-6", name:"RO K. Ahmed",        role:"RO",    username:"ro_dhaka1",   password:"pass123", stationId:null,     constituencyId:"CON-1" },
    { id:"OFF-7", name:"Admin S. Islam",     role:"ADMIN", username:"admin",       password:"admin123",stationId:null,     constituencyId:null  },
  ],

  voteRecords: {
    "BTH-1B": {
      boothId:"BTH-1B", boothNumber:"1B", stationId:"STN-1",
      votes:{ "CND-1":182, "CND-2":156, "CND-3":74, "CND-4":8 },
      rejectedBallots:10, totalVotesCast:430,
      issuedBallots:430, submittedBy:"apo_mirpur",
      submittedAt:"2026-12-28 08:10:22", status:"VERIFIED"
    },
    "BTH-3A": {
      boothId:"BTH-3A", boothNumber:"3A", stationId:"STN-2",
      votes:{ "CND-1":195, "CND-2":148, "CND-3":55, "CND-4":12 },
      rejectedBallots:10, totalVotesCast:420,
      issuedBallots:420, submittedBy:"apo_pallabi",
      submittedAt:"2026-12-28 08:55:10", status:"VERIFIED"
    },
    "BTH-3B": {
      boothId:"BTH-3B", boothNumber:"3B", stationId:"STN-2",
      votes:{ "CND-1":210, "CND-2":162, "CND-3":40, "CND-4":9 },
      rejectedBallots:14, totalVotesCast:435,
      issuedBallots:435, submittedBy:"apo_pallabi",
      submittedAt:"2026-12-28 09:02:44", status:"VERIFIED"
    },
  },

  auditLog: [
    { id:1,  actor:"admin",       role:"ADMIN", op:"CREATE_CANDIDATE",  entity:"Candidate",     entityId:"CND-1",  ts:"2026-12-01 09:00:00", ip:"192.168.1.1"   },
    { id:2,  actor:"admin",       role:"ADMIN", op:"CREATE_OFFICER",    entity:"Officer",       entityId:"OFF-1",  ts:"2026-12-01 09:15:00", ip:"192.168.1.1"   },
    { id:3,  actor:"apo_mirpur",  role:"APO",   op:"LOGIN",             entity:"Session",       entityId:"OFF-1",  ts:"2026-12-28 07:55:00", ip:"192.168.1.101" },
    { id:4,  actor:"apo_mirpur",  role:"APO",   op:"SUBMIT_VOTES",      entity:"PollingBooth",  entityId:"BTH-1B", ts:"2026-12-28 08:10:22", ip:"192.168.1.101" },
    { id:5,  actor:"po_mirpur",   role:"PO",    op:"LOGIN",             entity:"Session",       entityId:"OFF-3",  ts:"2026-12-28 09:00:00", ip:"192.168.1.102" },
    { id:6,  actor:"po_mirpur",   role:"PO",    op:"VERIFY_BOOTH",      entity:"PollingBooth",  entityId:"BTH-1B", ts:"2026-12-28 09:20:10", ip:"192.168.1.102" },
    { id:7,  actor:"po_mirpur",   role:"PO",    op:"FLAG_BOOTH",        entity:"PollingBooth",  entityId:"BTH-2B", ts:"2026-12-28 09:25:00", ip:"192.168.1.102" },
    { id:8,  actor:"apo_pallabi", role:"APO",   op:"SUBMIT_VOTES",      entity:"PollingBooth",  entityId:"BTH-3A", ts:"2026-12-28 08:55:10", ip:"192.168.1.103" },
    { id:9,  actor:"apo_pallabi", role:"APO",   op:"SUBMIT_VOTES",      entity:"PollingBooth",  entityId:"BTH-3B", ts:"2026-12-28 09:02:44", ip:"192.168.1.103" },
    { id:10, actor:"po_pallabi",  role:"PO",    op:"APPROVE_STATION",   entity:"PollingStation",entityId:"STN-2",  ts:"2026-12-28 09:45:00", ip:"192.168.1.104" },
    { id:11, actor:"aro_dhaka1",  role:"ARO",   op:"CONSOLIDATE",       entity:"Constituency",  entityId:"CON-1",  ts:"2026-12-28 10:05:00", ip:"192.168.1.105" },
    { id:12, actor:"ro_dhaka1",   role:"RO",    op:"PUBLISH_RESULT",    entity:"ElectionResult",entityId:"CON-1",  ts:"2026-12-28 10:30:00", ip:"192.168.1.106" },
  ],

  // Runtime state
  consolidatedResult: null,
  roSubmitted: false,
  currentUser: null,
  currentRole: null,
};

const PERSIST_KEY = 'ems_db_state';

function saveDBState() {
  try {
    const state = {
      voters: DB.voters,
      constituencies: DB.constituencies,
      stations: DB.stations,
      booths: DB.booths,
      candidates: DB.candidates,
      parties: DB.parties,
      officers: DB.officers,
      voteRecords: DB.voteRecords,
      auditLog: DB.auditLog,
      consolidatedResult: DB.consolidatedResult,
      roSubmitted: DB.roSubmitted,
    };
    localStorage.setItem(PERSIST_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn('Unable to save EMS state:', e);
  }
}

function loadDBState() {
  try {
    const raw = localStorage.getItem(PERSIST_KEY);
    if (!raw) return;
    const state = JSON.parse(raw);
    if (state.voters) DB.voters = state.voters;
    if (state.constituencies) DB.constituencies = state.constituencies;
    if (state.stations) DB.stations = state.stations;
    if (state.booths) DB.booths = state.booths;
    if (state.candidates) DB.candidates = state.candidates;
    if (state.parties) DB.parties = state.parties;
    if (state.officers) DB.officers = state.officers;
    if (state.voteRecords) DB.voteRecords = state.voteRecords;
    if (state.auditLog) DB.auditLog = state.auditLog;
    if (state.consolidatedResult !== undefined) DB.consolidatedResult = state.consolidatedResult;
    if (state.roSubmitted !== undefined) DB.roSubmitted = state.roSubmitted;
  } catch (e) {
    console.warn('Unable to restore EMS state:', e);
  }
}

function ensureDefaultAdmin() {
  if (!DB.officers.some(o => o.username.toLowerCase() === 'admin' && o.role.toUpperCase() === 'ADMIN')) {
    DB.officers.push({
      id:'OFF-7', name:'Admin S. Islam', role:'ADMIN', username:'admin', password:'admin123', stationId:null, constituencyId:null
    });
  }
}

(function restoreState() {
  loadDBState();
  ensureDefaultAdmin();
})();

// ─── Session helpers ────────────────────────────────────────────
function getSession() {
  try {
    const s = sessionStorage.getItem('ems_session');
    return s ? JSON.parse(s) : null;
  } catch(e) { return null; }
}
function setSession(user, role, name) {
  sessionStorage.setItem('ems_session', JSON.stringify({ user, role, name }));
  DB.currentUser = user; DB.currentRole = role;
}
function clearSession() {
  sessionStorage.removeItem('ems_session');
  DB.currentUser = null; DB.currentRole = null;
}
function logout() {
  if (DB.currentUser) addAudit(DB.currentUser, (DB.currentRole||'').toUpperCase(), 'LOGOUT', 'Session', DB.currentUser);
  clearSession();
}

// Restore session on load
(function restoreSession() {
  const s = getSession();
  if (s) { DB.currentUser = s.user; DB.currentRole = s.role; }
})();

// ─── Audit helper ───────────────────────────────────────────────
function addAudit(actor, role, op, entity, entityId) {
  DB.auditLog.push({
    id: DB.auditLog.length + 1,
    actor, role, op, entity, entityId,
    ts: new Date().toLocaleString('en-GB'),
    ip: `192.168.1.${100 + Math.floor(Math.random() * 50)}`
  });
}
